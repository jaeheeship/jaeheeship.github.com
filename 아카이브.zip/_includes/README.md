How to use Liquid Includes
=============================


In your code

	{% include name.filetipe %}