#!/bin/sh

sass --watch css/style.scss:css/style.css --style compressed

exit 0
